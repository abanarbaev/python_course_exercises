from setuptools import setup
setup(
    name='vsearch',
    version='0.1',
    description='The Head First Py Search Tools',
    author='HF Py 2e',
    author_email='hfpy2@gmail.com',
    url='headfirstlabs.com',
    py_modules=['vsearch'],
    )
