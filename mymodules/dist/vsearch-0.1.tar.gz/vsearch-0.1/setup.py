from setuptools import setup

setup(
    name='vsearch',
    version='0.01',
    description='High Quality Search System',
    author='John Reed',
    author_email='reed.johnnny@gmail.com',
    url='jreed.com',
    py_modules=['vsearch'],
    )
    
